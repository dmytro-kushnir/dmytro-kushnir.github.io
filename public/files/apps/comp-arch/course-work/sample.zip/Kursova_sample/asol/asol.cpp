#define _CRT_SECURE_NO_WARNINGS


#include <string>
#define MAXLINELENGTH 1000
#define MAXNUMLABELS 4096
#define MAXLABELLENGTH 7 /* includes the null character termination */
#define OPNUM 19


int readAndParse(FILE*, char*, char*, char*, char*, char*);
int translateSymbol(char labelArray[MAXNUMLABELS][MAXLABELLENGTH], int labelAddress[MAXNUMLABELS], int, char*);
int isNumber(char*);

class {
public:
	struct {
		char name[10];
		int typeOp[3];
		int typeCom;	// 0 � �������� �����
	}Code[OPNUM] = {
		{"add",1,1,1,1},
		{"nand",1,1,1,1},
		{"lw",1,1,2,0},
		{"sw",1,1,2,0},
		{"beq",1,1,2,0},
		{"jalr",1,1,0,1},
		{"halt",0,0,0,1},
		{"mul",1,1,1,1},

		{"inc",1,0,0,1},
		{"div",1,1,1,1},
		{"xsub",1,1,1,1},
		{"and",1,1,1,1},
		{"xor",1,1,1,1},
		{"cmple",1,1,1,1},
		{"jmae",1,1,2,0},
		{"jmne",1,1,2,0},
		{"bt",1,1,0,1},
		{"cmp",1,1,0,1},
		{"stc",0,0,0,1}
	};

	void TestArg(int address, char* opcode, char* arg0, char* arg1, char* arg2)
	{
		char* arg[3] = { arg0,arg1,arg2 };
		for (size_t i = 0; i < OPNUM; i++)
		{
			if (!strcmp(opcode, Code[i].name))
			{
				for (size_t j = 0; j < 3; j++)
				{
					if (Code[i].typeOp[j] == 0)
					{
						if (arg[j][0] != '\0')
						{
							printf("address %d: too mach arguments (argument %zd)\n", address, j);
							exit(2);
						}
					}
					if (Code[i].typeOp[j] == 1)
					{
						if ((!strcmp(opcode, "div") || !strcmp(opcode, "xsub") || !strcmp(opcode, "and")) && arg[2][0] == '#')
						{
							printf("address %d: bad character in register argument\n", address);
							exit(2);
						}
						else
						{
							testRegArg(address, opcode, arg[j]);
						}
					}
					if (Code[i].typeOp[j] == 2)
					{
						testAddrArg(address, arg[j]);
					}
				}
			}
			if (!strcmp(opcode, ".fill") && arg0[0] == '\0') {
				printf("error at address %d: not enough arguments\n", address);
				exit(2);
			}
		}
	}

	bool IsIllegal(char* opcode)
	{
		bool corect = 1 && strcmp(opcode, ".fill");
		for (size_t i = 0; i < OPNUM; i++)
		{
			corect = corect && strcmp(opcode, Code[i].name);
		}
		return !corect;
	}

	/*Test register argument; make sure it's in range and has no bad characters*/
	void testRegArg(int address, char* opcode, char* arg)
	{
		int num;
		char c;
		char temp[MAXLINELENGTH];
		strcpy(temp, arg);

		if ((!strcmp(opcode, "div") || !strcmp(opcode, "xsub") || !strcmp(opcode, "and")) && temp[0] == '#')
		{
			temp[0] = '0';
		}
		else if (atoi(temp) < 0 || atoi(temp) > 31) {
			printf("address %d: register out of range\n", address);
			exit(2);
		}
		if (sscanf(temp, "%d%c", &num, &c) != 1) {
			temp[0] == '\0' ? printf("address %d: not enough arguments\n", address) :
				printf("address %d: bad character in register argument\n", address);
			exit(2);
		}
	}

	/*Test addressField argument*/
	void testAddrArg(int address, char* arg)
	{
		int num;
		char c;

		char temp[MAXLINELENGTH];
		strcpy(temp, arg);
		if (isNumber(temp)) {
			if (sscanf(temp, "%d%c", &num, &c) != 1) {
				printf("address % d: bad character\n", address);
				exit(2);
			}
		}
	}

}OpCodeLib;


int main(int argc, char* argv[])
{
	char* inFileString, * outFileString;
	FILE* inFilePtr, * outFilePtr;
	int address;
	char* label = new char[MAXLINELENGTH], * opcode = new char[MAXLINELENGTH], * arg0 = new char[MAXLINELENGTH],
		* arg1 = new char[MAXLINELENGTH], * arg2 = new char[MAXLINELENGTH], * argTmp = new char[MAXLINELENGTH];
	int i;
	int numLabels = 0;
	long long int num;
	int addressField;

	char labelArray[MAXNUMLABELS][MAXLABELLENGTH];
	int* labelAddress = new int[MAXNUMLABELS];

	if (argc != 3) {
		printf("error: usage: %s <assembly-code-file> <machine-code-file>\n",
			argv[0]);
		exit(1);
	}

	inFileString = argv[1];
	outFileString = argv[2];

	inFilePtr = fopen(inFileString, "r");
	if (inFilePtr == NULL) {
		printf("error in opening %s\n", inFileString);
		exit(1);
	}
	outFilePtr = fopen(outFileString, "w");
	if (outFilePtr == NULL) {
		printf("error in opening %s\n", outFileString);
		exit(1);
	}

	/* map symbols to addresses */

	/* assume address start at 0 */
	for (address = 0; readAndParse(inFilePtr, label, opcode, arg0, arg1, arg2);
		address++) {
		if (!OpCodeLib.IsIllegal(opcode)) {
			printf("error: unrecognized opcode %s at address %d\n", opcode,
				address);
			exit(1);
		}

		OpCodeLib.TestArg(address, opcode, arg0, arg1, arg2);

		if (label[0] != '\0') {
			/* check for labels that are too long */
			if (strlen(label) >= MAXLABELLENGTH) {
				printf("error at address %d: label too long\n", address);
				exit(2);
			}

			/* make sure label starts with letter */
			if (!sscanf(label, "%[a-zA-Z]", argTmp)) {
				printf("error at address %d: label doesn't start with letter\n", address);
				exit(2);
			}

			/* make sure label consists of only letters and numbers */
			sscanf(label, "%[a-zA-Z0-9]", argTmp);
			if (strcmp(argTmp, label)) {
				printf("error at address %d: label has character other than letters and numbers\n", address);
				exit(2);
			}

			/* look for duplicate label */
			for (i = 0; i < numLabels; i++) {
				if (!strcmp(label, labelArray[i])) {
					printf("error at address %d: duplicate label %s\n", address, label);
					exit(1);
				}
			}
			/* see if there are too many labels */
			if (numLabels >= MAXNUMLABELS) {
				printf("error at address %d: too many labels (label=%s)\n", address, label);
				exit(2);
			}

			strcpy(labelArray[numLabels], label);
			labelAddress[numLabels++] = address;
		}
	}
	rewind(inFilePtr);
	for (address = 0; readAndParse(inFilePtr, label, opcode, arg0, arg1, arg2);
		address++) {

		for (size_t i = 0; i < OPNUM; i++)
		{
			if (!strcmp(opcode, OpCodeLib.Code[i].name))
			{
				if (OpCodeLib.Code[i].typeCom == 0)
				{
					char temp[MAXLINELENGTH];
					strcpy(temp, arg2);

					if (!isNumber(arg2)) {
						addressField = translateSymbol(labelArray, labelAddress,
							numLabels, arg2);
				
						if (!strcmp(opcode, "beq") || !strcmp(opcode, "jmae") || !strcmp(opcode, "jmne")) {
							addressField = addressField - address - 1;
						}
					}
					else {
						addressField = atoi(arg2);
					}

					if (addressField < -524288 || addressField > 524287) {
						printf("error: offset %d out of range\n", addressField);
						exit(1);
					}

					/* truncate the offset field, in case it's negative */
					addressField = addressField & 0xFFFFF;

					num = (i << 35) | (_atoi64(arg0) << 30) | (_atoi64(arg1) << 25) | addressField;
				}

				else if (OpCodeLib.Code[i].typeCom == 1)
				{
					if (!strcmp(opcode, "div") || !strcmp(opcode, "xsub") || !strcmp(opcode, "and"))
					{

						bool arg0Type = 0, arg1Type = 0;
						arg0[0] == '#' ? arg0[0] = '0', arg0Type = 1 : NULL;
						arg1[0] == '#' ? arg1[0] = '0', arg1Type = 1 : NULL;

						num = (i << 35) | (_atoi64(arg0) << 21) | (arg0Type << 20) | (arg1Type << 19) | (_atoi64(arg1) << 5) | _atoi64(arg2);
					}
					else
					{
						num = (i << 35) | (_atoi64(arg0) << 30) | (_atoi64(arg1) << 25) | _atoi64(arg2);
					}
				}
			}
		}




		if (!strcmp(opcode, ".fill")) {
			if (!isNumber(arg0)) {
				num = translateSymbol(labelArray, labelAddress, numLabels,
					arg0);
			}
			else {
				num = atoi(arg0);
				if (num < -549755813888 || num > 549755813887)
				{
					printf("error at address %d: grid overflow\n", address);
					exit(1);
				}
			}
		}
		/* printf("(address %d): %d (hex 0x%x)\n", address, num, num); */
		fprintf(outFilePtr, "%I64d\n", num);
	}

	exit(0);
}

int readAndParse(FILE* inFilePtr, char* label, char* opcode, char* arg0,
	char* arg1, char* arg2)
{
	char line[MAXLINELENGTH];
	char* ptr = line;

	/* delete prior values */
	label[0] = opcode[0] = arg0[0] = arg1[0] = arg2[0] = '\0';

	/* read the line from the assembly-language file */
	if (fgets(line, MAXLINELENGTH, inFilePtr) == NULL) {
		/* reached end of file */
		return(0);
	}

	/* check for line too long */
	if (strlen(line) == MAXLINELENGTH - 1) {
		printf("error: line too long\n");
		exit(1);
	}

	/* is there a label? */
	ptr = line;
	if (sscanf(ptr, "%[^\t\n ]", label)) {
		/* successfully read label; advance pointer over the label */
		ptr += strlen(label);
	}
	sscanf(ptr, "%*[\t\n\r ]%[^\t\n\r ]%*[\t\n\r ]%[^\t\n\r ]%*[\t\n\r ]%[^\t\n\r ]%*[\t\n\r ]%[^\t\n\r ]",
		opcode, arg0, arg1, arg2);

	arg0[0] == ';' ? arg0[0] = '\0', arg1[0] = '\0', arg2[0] = '\0' : NULL;
	arg1[0] == ';' ? arg1[0] = '\0', arg2[0] = '\0' : NULL;
	arg2[0] == ';' ? arg2[0] = '\0' : NULL;

	return(1);
}

int translateSymbol(char labelArray[MAXNUMLABELS][MAXLABELLENGTH],
	int labelAddress[MAXNUMLABELS], int numLabels, char* symbol)
{
	int i;

	/* search through address label table */
	for (i = 0; i < numLabels && strcmp(symbol, labelArray[i]); i++) {
	}

	if (i >= numLabels) {
		printf("error: missing label %s\n", symbol);
		exit(1);
	}

	return(labelAddress[i]);
}

int isNumber(char* string)
{
	/* return 1 if string is a number */

	int i;
	return((sscanf(string, "%d", &i)) == 1);
}
